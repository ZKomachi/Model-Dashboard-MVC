<?php
class RequestApi
{
    // Function para request api curl:
    public function sendCurl($url, $data, $post = false, $token = "")
    {
        $curl = curl_init("urldaminhaapi.com" . $url);
        curl_setopt($curl, CURLOPT_POST, $post);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($curl);
        curl_close($curl);
        return json_decode($response);
    }

    public function fileGetCont($url, $data = "", $token = "")
    {
        //Enviar pro model validar:
        $json = file_get_contents("urldaminhaapi.com" . $url);
        $values = json_decode($json);
        return $values;
    }
}
