<?php
class CheckLogin
{
}
