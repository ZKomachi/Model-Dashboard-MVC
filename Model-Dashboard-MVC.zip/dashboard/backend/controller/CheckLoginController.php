<?php
class CheckLoginController
{
}
