<?php
class CheckLoginView
{
}
