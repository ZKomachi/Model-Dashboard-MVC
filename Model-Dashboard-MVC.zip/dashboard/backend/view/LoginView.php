<?php
class LoginView
{
}
