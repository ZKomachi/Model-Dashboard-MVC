<?php
class MenuView
{
    public function generateAdmin($usuario, $ativo, $addNew, $ruta, $rutaAssets)
    {
        echo "
            $addNew
        ";
    }

    public function generateUsuario($usuario, $ativo, $addNew, $ruta, $rutaAssets)
    {
        echo "
            $addNew
        ";
    }
}
